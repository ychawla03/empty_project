INSERT INTO sale(product_name, customer_email, buying_price, selling_price)
VALUES ('p1', 'cust@gmail.com', 20, 30);
