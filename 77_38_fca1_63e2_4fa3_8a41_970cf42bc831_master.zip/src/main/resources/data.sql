INSERT INTO vehicle(brand, type, cc, color) VALUES('suzuki', 'hatchback' ,1200, 'red');
