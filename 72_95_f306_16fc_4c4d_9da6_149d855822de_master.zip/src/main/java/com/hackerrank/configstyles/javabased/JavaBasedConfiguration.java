package com.hackerrank.configstyles.javabased;

import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaBasedConfiguration {
}
