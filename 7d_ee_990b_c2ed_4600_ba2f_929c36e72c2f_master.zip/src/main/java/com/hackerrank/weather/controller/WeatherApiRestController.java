package com.hackerrank.weather.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class WeatherApiRestController {
}
